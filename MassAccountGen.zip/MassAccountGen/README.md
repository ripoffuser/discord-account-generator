
# Discord-Token-Generator

# How to use

WILL NOT WORK WITHOUT API KEY
WILL NOT WORK WITHOUT BALANCE ON CAPMONSTER
put your Proxy(s) in data\proxies.txt .
put your [CapMonster](https://capmonster.cloud) key and server invite code in data\config.json .
```json
    "invite_code": "Put your invite code here! ONLY THE CODE", 
    "capmonster_key": "Put your capmonster api key here!",
```


## This github repo is for EDUCATIONAL PURPOSES ONLY. I AM NOT RESPONSIBLE FOR WHAT YOU DO WITH THIS REPO.
